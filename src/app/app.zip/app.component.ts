import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tag Printing';
  PageName:string;
  setclass_cab:boolean;setclass_mesh:boolean;setclass_snc:boolean;
  setclass_prc:boolean;setclass_bpc:boolean;setclass_carpet:boolean;setclass_export:boolean;
  setclass_bcp:boolean;

  ShowPageName(name:string){
    this.PageName = name;
    if(name.trim() == "CAB"){
      this.setActiveclass();
      this.setclass_cab=true;
    }
    else if(name.trim() == "MESH"){
      this.setActiveclass();
      this.setclass_mesh=true;
    }
    else if(name.trim() == "SNC"){
      this.setActiveclass();
      this.setclass_snc=true;
    }
    else if(name.trim() == "PRC"){
      this.setActiveclass();
      this.setclass_prc=true;
    }
    else if(name.trim() == "BPC"){
      this.setActiveclass();
      this.setclass_bpc=true;
    }
    else if(name.trim() == "CARPET"){
      this.setActiveclass();
      this.setclass_carpet=true;
    }
    else if(name.trim() == "EXPORT"){
      this.setActiveclass();
      this.setclass_export=true;
    }
    else if(name.trim() == "BCP"){
      this.setActiveclass();
      this.setclass_bcp=true;
    }
  }

  setActiveclass(){
    this.setclass_cab=false;
    this.setclass_mesh=false;
    this.setclass_snc=false;
    this.setclass_prc=false;
    this.setclass_bpc=false;
    this.setclass_carpet=false;
    this.setclass_export=false;
    this.setclass_bcp= false;
  }
}




