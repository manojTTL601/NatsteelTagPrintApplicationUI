 
export class Cabmodel {
}

export class User {
    MST_User_ID:number=0;
    LoginId:string
}

export class Roll {
    MST_Role_ID:number=0;
    RoleName:string
}

export class ReleaseCode{
    Id:number=0;
    Value:string;
}

export class TagNumber{
    RunNo:string;
    isChecked:boolean;
}

export class WorkCenter{
    ID:number;
    workcenter:number;
    TagNoID:number;
    TagNumber:number;
    isChecked:boolean;
    Value:string;
}

export class GroupTagNumbers{
    Id:number;
    GroupTagNumber:number;
    WorkCenterId:number;
    isChecked:boolean;
    TagNo:string;
    isDisable:boolean= false;
}

export class TagNumberToPrint{
    Id:number;
    TagNumberToPrint:number;
    GroupTagNumberId:number;
    isChecked:Boolean;
    TagNo:string;
    isTagNumberDisable:boolean=false;
}
export class tagNumberToPrinTo{
    TagNo:string;
    isDisableTag:boolean;
}

export class PrinterName{
    Id:string;
    Name:string;
}

export class GetLibrarianFile{
    Id:string;
    Name:string;
}

export class NoOfdaylist{
  value = [
    { value: 1},{ value: 2}, { value: 3}, { value: 4}, { value: 5}, { value: 6}, { value: 7}, { value: 8},
    { value: 9}, { value: 10}, { value: 11}, { value: 12}, { value: 13}, { value: 14}, { value: 15}, { value: 16},
    { value: 17}, { value: 18}, { value: 19}, { value: 20}, { value: 21}, { value: 22}, { value: 23}, { value: 24},
    { value: 25}, { value: 26}, { value: 27}, { value: 28}, { value: 29}, { value: 30}, { value: 31}, { value: 32},
    { value: 33}, { value: 34}, { value: 35}, { value: 36}, { value: 37}, { value: 38}, { value: 39}, { value: 40},
  ];
}


export class MeshProduct {
    // ReleaseCodeID:number=0;
    // ReleaseCodeValue:string;
    // RunNoID:number;
    // RunNoValue:string;
    // BBSNoID:number=0;
    // BBSNoValue:string;

    Value: string;
}

// export class PrinterName {
    
//     Name: any;
// }

export class ProductMesh {

    Value: any;
}

export class GetLibrarian {
    Id: string;
    Name: string;
}

export class TypeMesh {


}

export class GradeMesh {

    Value: any;
}

export class BatchMesh {

    Value: any;
}

export class ProductPrecut {
    Value: any;
}

export class DeliverToPrecut {
    Value: any;
}

export class MeshTemplateValue {
    Value: any;
}


// <product>A786(A11)</product>

// <qtysize>1.2pc x 2.3m </qtysize>

// <grade>B700A</grade>

// <type>SQUARE MESH</type>

// <unitWt>400KG</unitWt>

// <DOM>20/9/2022</DOM>

// <remark>Testing of malasiya sirim mesh tag</remark>

// <batchNo>PO987645</batchNo>

// <heatNo/>

// <noOfTag>10</noOfTag>

// <tagNumber>1</tagNumber>

export class MalasiyaSirim {
    product: string;
    qtysize: string;
    grade: string;
    type: string;
    unitWt: string;
    DOM: string;
    remark: string;
    batchNo: string;
    heatNo: string;
    noOfTag: string;
    tagNumber: string;
    printername: string;
    templatefile: string;
}

export class MalasiyaPrecut {
    product: string;
    qtysize: string;
    deliverto: string;
    acrscert: string;
    remark: string;
    custpo: string;
    noOfTag: string;
    tagNumber: string;
    printername: string;
    templatefile: string;
   

}

export class LoadxmlMesh {

    NewProductMesh: any;
    NewGradeMesh: any;
    NewTypeMesh: any;
    NewBatchNoMesh: any;

}

export class LoadxmlPrecut {

    NewProductPrecut: any;
    NewDeliveryLoc: any;

}


export class NoOfTags {
    value = [
        { value: 1 }, { value: 2 }, { value: 3 }, { value: 4 }, { value: 5 }, { value: 6 }, { value: 7 }, { value: 8 },
        { value: 9 }, { value: 10 }, { value: 11 }, { value: 12 }, { value: 13 }, { value: 14 }, { value: 15 }, { value: 16 },
        { value: 17 }, { value: 18 }, { value: 19 }, { value: 20 }, { value: 21 }, { value: 22 }, { value: 23 }, { value: 24 },
        { value: 25 }, { value: 26 }, { value: 27 }, { value: 28 }, { value: 29 }, { value: 30 }, { value: 31 }, { value: 32 },
        { value: 33 }, { value: 34 }, { value: 35 }, { value: 36 }, { value: 37 }, { value: 38 }, { value: 39 }, { value: 40 },
        { value: 41 }, { value: 42 }, { value: 43 }, { value: 44 }, { value: 45 }, { value: 46 }, { value: 47 }, { value: 48 },
        { value: 49 }, { value: 50 }
    ];
}

export class totaltags {
    Value: number;
}

export class NoOfdaylistcarpet{
    value = [
      { value: 1},{ value: 2}, { value: 3}, { value: 4}, { value: 5}, { value: 6}, { value: 7}, { value: 8},
      { value: 9}, { value: 10}, { value: 11}, { value: 12}, { value: 13}, { value: 14}, { value: 15}, { value: 16},
      { value: 17}, { value: 18}, { value: 19}, { value: 20}, { value: 21}, { value: 22}, { value: 23}, { value: 24},
      { value: 25}, { value: 26}, { value: 27}, { value: 28}, { value: 29}, { value: 30}, { value: 31}, { value: 32},
      { value: 33}, { value: 34}, { value: 35}, { value: 36}, { value: 37}, { value: 38}, { value: 39}, { value: 40},
      { value: 41}, { value: 42}, { value: 43}, { value: 44}, { value: 45}, { value: 46}, { value: 47}, { value: 48},
      { value: 49}, { value: 50}, { value: 51}, { value: 52}, { value: 53}, { value: 54}, { value: 55}, { value: 56},
      { value: 57}, { value: 58}, { value: 59}, { value: 60}, { value: 61}, { value: 62}, { value: 63}, { value: 64},
      { value: 65}, { value: 66}, { value: 67}, { value: 68},{ value: 69}, { value: 70},{ value: 71}, { value: 72}, { value: 73}, { value: 74},
      { value: 75}, { value: 76}, { value: 77}, { value: 78},{ value: 79},{ value: 80}, { value: 81}, { value: 82}, { value: 83}, { value: 84},
      { value: 85}, { value: 86}, { value: 87}, { value: 88},{ value: 89},{ value: 90},{ value: 91}, { value: 92}, { value: 93}, { value: 94},
      { value: 95}, { value: 99}, { value: 97}, { value: 98},{ value: 99},{ value: 100},{ value: 101},{ value: 102},{ value: 103},
      { value: 104},{ value: 105},
      { value: 106},{ value: 107},{ value: 108},{ value: 109},{ value: 110}
  
    ];
  }
  


